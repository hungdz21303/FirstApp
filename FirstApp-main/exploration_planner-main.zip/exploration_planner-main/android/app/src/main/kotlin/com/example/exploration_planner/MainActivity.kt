package com.example.exploration_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
