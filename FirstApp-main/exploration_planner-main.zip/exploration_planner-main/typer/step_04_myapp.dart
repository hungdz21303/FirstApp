import 'package:flutter/material.dart';

void main() => runApp(
    // MaterialApp
    // Scaffold
    // AppBar
    // Text
    // body: Column
    // text, text, text
    // image
    // Row
    // text, text, button
    // ....
    );

class MyApp extends StatelessWidget {
  
}
